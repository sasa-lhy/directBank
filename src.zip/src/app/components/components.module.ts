import {NgModule} from '@angular/core';
import {FProductComponent} from './f-product/f-product.component';
import {CountDownComponent} from './count-down/count-down.component';
import {HomeItemComponent} from './home-item/home-item.component';

@NgModule({
    declarations: [FProductComponent, CountDownComponent,HomeItemComponent],
    imports: [],
    exports: [FProductComponent, CountDownComponent,HomeItemComponent]
})
export class ComponentsModule {
}
