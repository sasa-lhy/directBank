import {Component, Input, OnInit} from '@angular/core';

@Component({
    selector: 'app-f-product',
    templateUrl: './f-product.component.html',
    styleUrls: ['./f-product.component.scss'],
})
export class FProductComponent implements OnInit {
    private _src: string;
    private _title: string;
    private _ad:string;
    @Input()
    set ad(value: string) {
        this._ad = value;
    }
    @Input()
    set src(value: string) {
        this._src = value;
        console.log('src:' + this._src);
    }
    @Input()
    set title(value: string) {
        this._title = value;
        console.log('title:' + this._title);
    }

    constructor() {
        console.log('生成了');
    }

    ngOnInit() {
    }

}
