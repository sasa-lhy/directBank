import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-home-item',
  templateUrl: './home-item.component.html',
  styleUrls: ['./home-item.component.scss'],
})
export class HomeItemComponent implements OnInit {
    private _src:string;
    private _title:string;
    @Input()
    set src(value: string) {
        this._src = value;
        console.log(this._src);
    }

    @Input()
    set title(value: string) {
        this._title = value;
        console.log(this._src);
    }
  constructor() { }

  ngOnInit() {}

}
