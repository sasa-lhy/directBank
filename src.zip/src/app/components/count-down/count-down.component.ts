import {Component, EventEmitter, OnInit, Output} from '@angular/core';

@Component({
    selector: 'app-count-down',
    templateUrl: './count-down.component.html',
    styleUrls: ['./count-down.component.scss'],
})
export class CountDownComponent implements OnInit {
    txt = '获取验证码';
    second = 60;
    timer;
    @Output()
    endOfCount:EventEmitter<boolean>= new EventEmitter();
    constructor() {
    }



    startCount() {
        console.log('倒计时启动了');
        if (!this.timer) {
            this.second = 60;
            this.timer = setInterval(() => {
                if (this.second <= 0) {
                    clearInterval(this.timer);
                    this.timer = undefined;
                    this.txt = '获取验证码';
                    this.endOfCount.emit(false);
                } else {
                    this.second--;
                    this.txt = this.second + 's';
                }

            }, 1000);
        }
    }

    ngOnInit() {
    }

}
