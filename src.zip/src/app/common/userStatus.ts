export let Constants = {
    server_url: 'http://www.dbank.chenwei.site/portal4m',
    img_serve_url:'http://120.79.47.193:8080/PhotoServer_war/photo/upload.do',
};
export const InterceptWhiteList={
    url:[
        'http://www.baidu.com'
        ]
}
