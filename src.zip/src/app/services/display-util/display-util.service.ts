import {Injectable} from '@angular/core';
import {AlertController, LoadingController, NavController, ToastController} from '@ionic/angular';

@Injectable({
    providedIn: 'root'
})
export class DisplayUtilService {
    loading;

    constructor(
        private alertCtrl: AlertController,
        private loadingCtrl: LoadingController,
        private toastCtrl: ToastController,
        private navCtrl: NavController
    ) {
        console.log('tip:显示弹框，加载，提示服务已启动！');
    }

    /**
     *  显示弹框(alert)
     * @param {string} header 标题
     * @param {string} subHeader 内容
     */
    async showAlert(subHeader: string = '您尚未开户，是否前往开户？', text: string = '去开户', url: string = '/add-card') {
        const alert = await this.alertCtrl.create({
            subHeader: subHeader,
            backdropDismiss: true,
            buttons: [
                {
                    text: '取消',
                    role: 'cancel',
                }, {
                    text: text, handler: () => {
                        this.navCtrl.navigateForward(url);
                    }
                },
            ]
        });
        return alert.present();
    }

    async showOneAlert(subHeader: string = '') {
        const alert = await this.alertCtrl.create({
            subHeader: subHeader,
            backdropDismiss: true,
            buttons: [
                {
                    text: '确定',
                    role: 'cancel',
                }
            ]
        });
        return alert.present();
    }

    // async showPasswordAlert(){
    //     const alert = await this.alertCtrl.create({
    //         header: '请输入支付密码',
    //         backdropDismiss: true,
    //         inputs: [
    //             {
    //                 name: 'payPwd',
    //                 type: 'text',
    //             }
    //         ]
    //     });
    //     return alert.present();
    // }

    /**
     * ion-loading 加载动画(loading)
     * @param message: 页面加载时显示的内容
     * @param duration：关闭加载指示器之前等待的毫秒数
     * @param spinner: 要显示的旋转器的名称
     * @param translucent: 加载指示符是否半透明
     */

    async showLoading(message: string = '', spinner: spinnerList = spinnerList.bubbles) {
        this.loading = await this.loadingCtrl.create({
            message: message,
            spinner: spinner,
        });
        return this.loading.present();
    }

     hideLoading() {
        if(this.loading){
            this.loading.dismiss();
        }

    }

    /**
     * ion-toast 提示（toast）
     * @param message
     * @param position：top, bottom, middle
     * @param closeButtonText
     * @param duration
     */
    async showToast(message: string = 'Your settings have been saved.', position: toastPosition = toastPosition.bottom,
                    duration: number = 1000) {
        const toast = await this.toastCtrl.create({
            message: message,
            position: position,
            showCloseButton: false,
            duration: duration
        });
        if (duration < 0) {
            toast.duration = Math.abs(duration);
        }
        return toast.present();
    }


}

export enum spinnerList {
    bubbles = 'bubbles',
    circles = 'circles',
    crescent = 'crescent',
    dots = 'dots',
    lines = 'lines',
    linesSmall = 'lines-small'
}

export enum toastPosition {
    top = 'top',
    bottom = 'bottom',
    middle = 'middle'
}