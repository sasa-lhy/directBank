import {Injectable} from '@angular/core';
import {HttpClient, HttpEvent, HttpHandler, HttpRequest, HttpResponse} from '@angular/common/http';
import {HttpProceedHandlerService} from './http-proceed-handler.service';
import {HttpPreviewHandlerService} from './http-preview-handler.service';
import {HttpExceptionHandlerService} from './http-exception-handler.service';
import {Observable, throwError} from 'rxjs';
import {InterceptWhiteList} from '../../common/userStatus'
import {catchError, map, timeout} from 'rxjs/operators';
@Injectable({
    providedIn: 'root'
})
export class HttpInterceptorService {

    constructor(
        public http: HttpClient,
        private httpProcessedHandler: HttpProceedHandlerService,
        private httpPreviewHandler: HttpPreviewHandlerService,
        private httpExceptionHandler: HttpExceptionHandlerService,
    ) {
    }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        console.log('进入拦截器:0');
        /**
         * 拦截器白名单处理
         */
        const uri = request.url;
        for (const url of InterceptWhiteList.url) {
            if (url.startsWith(uri)) {
                return next.handle(request);
            }
        }
        if (request.url.startsWith('http') || request.url.startsWith('https')) {
            return next.handle(request).pipe(
                map(event => {
                    timeout(2000);
                    /**
                     * 请求后置处理
                     */
                    if (event instanceof HttpResponse) {
                        //请求成功处理
                        return this.httpProcessedHandler.handle(event);
                    }
                    return event;
                }),
                catchError((err: any) => {
                    console.log(err);
                    this.httpExceptionHandler.handle(err);
                    return throwError(err);
                }),
            );
        }
        /**
         * 前置处理
         */
        request = this.httpPreviewHandler.handle(request);
        console.log('进入拦截器:0')
        return next.handle(request).pipe(
            map(event => {
                timeout(2000);
                /**
                 * 请求后置处理
                 */
                if (event instanceof HttpResponse) {
                    //请求成功处理
                    return this.httpProcessedHandler.handle(event);
                }
                return event;
            }),
            catchError((err: any) => {
                console.log(err);
                this.httpExceptionHandler.handle(err);
                return throwError(err);
            }),
        );
    }
}
