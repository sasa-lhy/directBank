import {Injectable} from '@angular/core';
import {HttpResponse} from '@angular/common/http';
import {DisplayUtilService} from '../display-util/display-util.service';
import {NavController} from '@ionic/angular';

@Injectable({
    providedIn: 'root'
})
export class HttpProceedHandlerService {

    constructor(private display: DisplayUtilService,private nav:NavController) {
    }

    handle(res: HttpResponse<any>): HttpResponse<any> {
        console.log('进入后置处理！');

            console.log(this.display.loading);
            this.display.hideLoading();
            console.log(this.display.loading);

        const resCopy = res.body;
        if (!resCopy.code) {
            this.display.showOneAlert('warn:缺少状态码,后置处理失效...');
            return res;
        }
        if (resCopy.code !== '000000') {
            if (resCopy.msg) {
                if(resCopy.code==='888888'){
                    this.display.showAlert(resCopy.msg,'忘记密码？','/forget-pass')
                }else{
                    this.display.showOneAlert('msg:' + resCopy.msg);
                }
            } else {
                this.display.showOneAlert('warn:缺少状态描述信息,状态码为:' + resCopy.code);
            }
            if(resCopy.code==='999999'){
                localStorage.clear();
                this.display.showOneAlert('登陆失效，请重新登陆！')
                this.nav.navigateForward('/login');
            }
            if(resCopy.code==='777777'){
                this.display.showOneAlert('忘记交易密码，去找回！')
                this.nav.navigateForward('/forget-paypwd');
            }

        } else {
            this.display.showToast(resCopy.msg);
            return res;
        }
    }
}

export interface ResponseData {
    code: string;
    data: any;
    msg: string;
}
