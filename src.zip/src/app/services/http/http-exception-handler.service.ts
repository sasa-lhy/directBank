import {Injectable} from '@angular/core';
import {DisplayUtilService} from '../display-util/display-util.service';
import {HttpResponse} from '@angular/common/http';
import {TimeoutError} from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class HttpExceptionHandlerService {

    constructor(private display: DisplayUtilService) {
    }

    handle(res) {
        console.log('进入异常处理');

        this.display.hideLoading();

        if (res instanceof HttpResponse) {
            switch (res.status) {
                case 200:
                    this.display.showOneAlert(res.status+':业务异常');
                    break;
                case 404:
                    this.display.showOneAlert(res.status+':请求失败，未找到请求地址!');
                    break;
                case 500:
                    this.display.showOneAlert(res.status+':请求失败，服务器出错，请稍后再试!');
                    break;
                case 0:
                    this.display.showOneAlert(res.status+':请求失败，请求响应出错!');
                    break;
                default:
                    this.display.showOneAlert(res.status+':请求失败，请稍候重试');
                    break;
            }
        } else {
            if (res instanceof TimeoutError) {
                this.display.showOneAlert('请求超时');
            } else {
                this.display.showOneAlert('请求失败，请稍候重试');
            }
        }
    }
}
