import {Injectable} from '@angular/core';
import {HttpRequest} from '@angular/common/http';
import {Constants} from '../../common/userStatus';
import {DisplayUtilService} from '../display-util/display-util.service';

@Injectable({
    providedIn: 'root'
})
export class HttpPreviewHandlerService {

    constructor(private display: DisplayUtilService) {
    }

    handle(req: HttpRequest<any>): HttpRequest<any> {
        this.display.showLoading();
        console.log('进入前置处理');
        const url = req.url;
        const headers = req.headers;
        const requestCopy = req.clone({
            url: Constants.server_url + req.url,
            body: req.body,
            params: req.params,
            setHeaders: {
                'Authorization': localStorage.getItem('sessionId')||'hh'
            }
        });
        console.log(requestCopy);
        console.log(requestCopy.url);
        return requestCopy;
    }
}
