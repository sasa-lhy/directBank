import {Injectable} from '@angular/core';
import {Camera, CameraOptions} from '@ionic-native/camera/ngx';
import {Constants} from '../../common/userStatus';
import {FileTransfer, FileUploadOptions, FileTransferObject} from '@ionic-native/file-transfer/ngx';
import {ActionSheetController} from '@ionic/angular';

@Injectable({
    providedIn: 'root'
})
export class UploadImgService {
    constructor(private camera: Camera, private transfer: FileTransfer) {

    }

    async doUploadImg(src) {
        const options: CameraOptions = {
            quality: 100,
            destinationType: this.camera.DestinationType.FILE_URI,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE,
            sourceType: src,
        };
        const img = await this.camera.getPicture(options);
        return this.doUpload(img);
    }

    async doUpload(url: string){
        const fileTransfer: FileTransferObject = this.transfer.create();
        let options: FileUploadOptions = {
            fileKey: 'files',
            fileName: 'files.jpg',
            headers: {},
        };
        const urlData=await fileTransfer.upload(url, Constants.img_serve_url, options);
        return urlData;
    }
}

export interface ResponseData {
    code: string;
    data: any;
    msg: string;
}