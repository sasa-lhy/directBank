import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {RouteReuseStrategy} from '@angular/router';

import {AlertController, IonicModule, IonicRouteStrategy, LoadingController, ToastController} from '@ionic/angular';
import {SplashScreen} from '@ionic-native/splash-screen/ngx';
import {StatusBar} from '@ionic-native/status-bar/ngx';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {DirectivesModule} from './directives/directives.module';
import {ComponentsModule} from './components/components.module';
import {HTTP_INTERCEPTORS, HttpClient, HttpClientModule} from '@angular/common/http';
import {DisplayUtilService} from './services/display-util/display-util.service';
import {HttpInterceptorService} from './services/http/http-interceptor.service';
import {HttpProceedHandlerService} from './services/http/http-proceed-handler.service';
import {HttpPreviewHandlerService} from './services/http/http-preview-handler.service';
import {HttpExceptionHandlerService} from './services/http/http-exception-handler.service';
import {UploadImgService} from './services/upload/upload-img.service';

@NgModule({
    declarations: [AppComponent],
    entryComponents: [],
    imports: [BrowserModule, IonicModule.forRoot(), AppRoutingModule, DirectivesModule, ComponentsModule, HttpClientModule],
    providers: [
        UploadImgService,
        AlertController,
        LoadingController,
        ToastController,
        DisplayUtilService,
        HttpClient,
        StatusBar,
        SplashScreen,
        HttpProceedHandlerService,
        HttpPreviewHandlerService,
        HttpExceptionHandlerService,
        {provide: RouteReuseStrategy, useClass: IonicRouteStrategy},
        {provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorService, multi: true},
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
