import {Component, OnInit, ViewChild} from '@angular/core';
import {CountDownComponent} from '../../../components/count-down/count-down.component';
import {HttpClient} from '@angular/common/http';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {NavController} from '@ionic/angular';
import {ResponseData} from '../../../services/http/http-proceed-handler.service';

@Component({
    selector: 'app-add-card',
    templateUrl: './add-card.page.html',
    styleUrls: ['./add-card.page.scss'],
})
export class AddCardPage implements OnInit {
    @ViewChild(CountDownComponent) countDownComp: CountDownComponent;
    conformForm: FormGroup;
    cardNumber = '';
    realName = '';
    idCard = '';
    phoneNum = '';
    job = '';
    code = '';
    cardNumberControl: AbstractControl;
    realNameControl: AbstractControl;
    idCardControl: AbstractControl;
    phoneNumControl: AbstractControl;
    jobControl: AbstractControl;
    codeControl: AbstractControl;
    codeBoolean = false;
    constructor(private fb: FormBuilder, private http: HttpClient, private nav: NavController) {
        this.conformForm = this.fb.group({
            cardNumber: ['', Validators.compose([Validators.required, Validators.pattern(/^[0-9]{18}$/)])],
            realName: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z\u4e00-\u9fa5]+$/)])],
            idCard: ['', Validators.compose([Validators.required, Validators.pattern(/^[0-9]{17}[0-9X]$/)])],
            phoneNum: ['', Validators.compose([Validators.required, Validators.pattern(/^[1][3,4,5,6,7,8][0-9]{9}$/)])],
            job: ['', Validators.compose([Validators.required])],
            code: ['', Validators.compose([Validators.required, Validators.pattern(/^[0-9]{6}$/)])],
        });
        this.cardNumberControl = this.conformForm.controls.cardNumber;
        this.realNameControl = this.conformForm.controls.realName;
        this.idCardControl = this.conformForm.controls.idCard;
        this.phoneNumControl = this.conformForm.controls.phoneNum;
        this.jobControl = this.conformForm.controls.job;
        this.codeControl = this.conformForm.controls.code;
    }


    async getCode() {
        this.codeBoolean=true;
        console.log(this.codeBoolean);
        await this.http.post('/user/code.do', {
            phone: this.phoneNum
        }).subscribe(
            (success: ResponseData) => {
                if (success.code === '000000') {
                    this.countDownComp.startCount();
                    console.log('msg' + success.msg);
                } else {
                    alert(success.msg);
                    console.log('msg' + success.msg);
                }
            }, (error) => {
                this.codeBoolean=false;
                console.log(error);
            }
        );

    }
    endOfCount(data){
        this.codeBoolean=false;
    }


    async doConform() {
        await this.http.post('/user/identityEffective.do', {
            cardNum: this.cardNumber,
            trueName: this.realName,
            idNum: this.idCard,
            phone: this.phoneNum,
            job: this.job,
            code: this.code,
        }).subscribe(
            (success: ResponseData) => {
                    if (success.code === '000000') {
                        console.log('msg' + success.msg);
                        this.nav.navigateForward('/verify');
                    } else {
                        alert(success.msg);
                        console.log('msg' + success.msg);
                    }
            }, (error) => {
                console.log(error);
            }
        );
    }
    ngOnInit() {
    }
}

