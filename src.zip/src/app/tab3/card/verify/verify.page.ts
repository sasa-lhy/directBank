import {Component, OnInit} from '@angular/core';
import {UploadImgService} from '../../../services/upload/upload-img.service';
import {HttpClient} from '@angular/common/http';
import {ActionSheetController, NavController} from '@ionic/angular';
import {Camera} from '@ionic-native/camera/ngx';

@Component({
    selector: 'app-verify',
    templateUrl: './verify.page.html',
    styleUrls: ['./verify.page.scss'],
})
export class VerifyPage implements OnInit {
    front = 'assets/shapes.svg';
    back = 'assets/shapes.svg';
    data;
    buttonCtrl1 = false;
    buttonCtrl2 = false;

    constructor(private uploadImg: UploadImgService, private http: HttpClient, private nav: NavController, private actionSheet: ActionSheetController,private camera: Camera) {
    }

    async showSelect(b) {
        const myActionSheet = await this.actionSheet.create({
            header: '获取图片',
            buttons: [{
                text: '拍照获取',
                handler: () => {
                    const mySource1 = this.camera.PictureSourceType.CAMERA;
                    const data = this.uploadImg.doUploadImg(mySource1).then(
                        (data)=>{
                            console.log('sdjbvdj'+JSON.stringify(data));
                            console.log(data.response);
                            if(b){
                                this.front=data.response;
                                this.buttonCtrl1 = true;
                            }else{
                                this.back=data.response;
                                this.buttonCtrl2 = true;
                            }

                        }
                    );
                }
            }, {
                text: '从图库获取',
                handler: () => {
                    const mySource2 = this.camera.PictureSourceType.PHOTOLIBRARY;
                    const data = this.uploadImg.doUploadImg(mySource2).then(
                        (data)=>{
                            if(b){
                                this.front=data.response;
                                this.buttonCtrl1 = true;
                            }else{
                                this.back=data.response;
                                this.buttonCtrl2 = true;
                            }

                        }
                    );
                }
            }, {
                text: '取消',
                icon: 'close',
                role: 'cancel',
                handler: () => {
                    console.log('Cancel clicked');
                }
            }]
        });
        await myActionSheet.present();
    }

    ngOnInit() {
    }

    testImg1() {
        this.showSelect(true);
    }

    testImg2() {
        this.showSelect(false);
    }

    async doUploadUrl() {
        await this.http.post('/user/uploadPhoto.do', {
            cardFront: this.front,
            cardBack: this.back
        }).subscribe(
            (success: ResponseData) => {
                if (success.code === '000000') {
                    this.buttonCtrl1 = false;
                    this.buttonCtrl2 = false;
                    this.nav.navigateForward('/set-password');
                }
            }, (error) => {
                console.log(error);
            }
        );
    }

}

export interface ResponseData {
    code: string;
    data: any;
    msg: string;
}
