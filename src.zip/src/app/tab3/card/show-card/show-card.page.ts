import {Component, OnInit} from '@angular/core';
import {ActivatedRoute,Params} from '@angular/router';
@Component({
    selector: 'app-show-card',
    templateUrl: './show-card.page.html',
    styleUrls: ['./show-card.page.scss'],
})
export class ShowCardPage implements OnInit {
    name = '-';
    account = '-';
    bank = '-';
    phone = '-';
    result = '开户成功';

    constructor(private activeRoute:ActivatedRoute) {
        this.activeRoute.queryParams.subscribe((params:Params)=>{
            console.log(params);
            this.name=params['trueName'];
            this.account=params['cardNum'];
            this.phone=params['phone'];
            this.bank = params['bankType'];
        });
    }

    ngOnInit() {

    }

}
