import {Component, OnInit} from '@angular/core';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {HttpClient} from '@angular/common/http';
import {ResponseData} from '../../../services/http/http-proceed-handler.service';
import {Router} from '@angular/router';

@Component({
    selector: 'app-set-password',
    templateUrl: './set-password.page.html',
    styleUrls: ['./set-password.page.scss'],
})
export class SetPasswordPage implements OnInit {
    passwordForm: FormGroup;
    password1value = '';
    password2value = '';
    password1Control: AbstractControl;
    password2Control: AbstractControl;
    trueName;
    cardNum;
    bankType;
    phone;
    constructor(private fb: FormBuilder, private router: Router, private http: HttpClient) {
        this.passwordForm = this.fb.group({
            password1: ['', Validators.compose([Validators.required, Validators.pattern(/^[0-9]{6}$/)])],
            password2: ['', Validators.compose([Validators.required, Validators.pattern(/^[0-9]{6}$/)])],
        });
        this.password1Control = this.passwordForm.controls.password1;
        this.password2Control = this.passwordForm.controls.password2;

    }

    async doSetPass() {
        await this.http.post('/user/createEAccount.do', {
            tradePassWd: this.password1value
        }, {
            headers: {
                'Authorization': localStorage.getItem('sessionId')
            }
        }).subscribe(
            (success: ResponseData) => {
                if (success.code === '000000') {
                    localStorage.setItem('opened', 'true');
                    this.trueName=success.data.trueName;
                    this.cardNum=success.data.cardNum;
                    this.bankType=success.data.bankType;
                    this.phone=success.data.phone;
                    this.router.navigate(['/show-card'],{
                        skipLocationChange: true,
                        queryParams:{
                            trueName:this.trueName,
                            cardNum:this.cardNum,
                            bankType:this.bankType,
                            phone:this.phone,
                        }
                    })
                }
            }, (error) => {
                console.log(error);
            }
        );
    }

    ngOnInit() {
    }

}

