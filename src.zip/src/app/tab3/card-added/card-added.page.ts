import {Component, OnInit} from '@angular/core';
import {NavController} from '@ionic/angular';
import {HttpClient} from '@angular/common/http';
import {ResponseData} from '../../services/http/http-proceed-handler.service';

@Component({
    selector: 'app-card-added',
    templateUrl: './card-added.page.html',
    styleUrls: ['./card-added.page.scss'],
})
export class CardAddedPage implements OnInit {
    bank = '';
    cardNum = '';

    constructor(private nav:NavController,private http:HttpClient) {
    }

    ionViewWillEnter() {
        this.getMyCard();
    }

    ngOnInit() {
    }

    toMe(){
        this.nav.navigateBack('tabs/tab3');
    }


    async getMyCard(){
        await this.http.post('/app/findCardInfo.do',{}).subscribe(
            (success:ResponseData)=>{
                if(success.code==='000000'){
                    this.cardNum = success.data.cardNum;
                    this.bank = success.data.bankType;
                }
            },(error)=>{
                console.log(error);
            }
        )
    }
}
