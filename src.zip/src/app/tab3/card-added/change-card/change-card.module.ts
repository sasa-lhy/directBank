import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {Routes, RouterModule} from '@angular/router';

import {IonicModule} from '@ionic/angular';

import {ChangeCardPage} from './change-card.page';
import {ComponentsModule} from '../../../components/components.module';

const routes: Routes = [
    {
        path: '',
        component: ChangeCardPage
    }
];

@NgModule({
    imports: [
        ComponentsModule,
        ReactiveFormsModule,
        CommonModule,
        FormsModule,
        IonicModule,
        RouterModule.forChild(routes)
    ],
    declarations: [ChangeCardPage]
})
export class ChangeCardPageModule {
}
