import {Component, OnInit, ViewChild} from '@angular/core';
import {CountDownComponent} from '../../../components/count-down/count-down.component';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {HttpClient} from '@angular/common/http';
import {NavController} from '@ionic/angular';
import {ResponseData} from '../../../services/http/http-proceed-handler.service';

@Component({
    selector: 'app-change-card',
    templateUrl: './change-card.page.html',
    styleUrls: ['./change-card.page.scss'],
})
export class ChangeCardPage implements OnInit {
    @ViewChild(CountDownComponent) countDownComp: CountDownComponent;
    changeForm: FormGroup;
    phonevalue = '';
    validvalue = '';
    cardnumvalue = '';
    mobileControl: AbstractControl;
    cardnumControl: AbstractControl;
    validcodeControl: AbstractControl;
    codeBoolean = false;
    constructor(private http: HttpClient, private fb: FormBuilder, private nav: NavController) {
        this.changeForm = this.fb.group({
            mobile: ['', Validators.compose([Validators.required, Validators.pattern(/^[1][3,4,5,6,7,8][0-9]{9}$/)])],
            validcode: ['', Validators.compose([Validators.required, Validators.pattern(/^[0-9]{6}$/)])],
            cardnum: ['', Validators.compose([Validators.required, Validators.pattern(/^[0-9]{18}$/)])],
        });
        this.mobileControl = this.changeForm.controls.mobile;
        this.cardnumControl = this.changeForm.controls.cardnum;
        this.validcodeControl = this.changeForm.controls.validcode;
    }

    ngOnInit() {
    }

    async getCode() {
        this.codeBoolean=true;
        console.log(this.codeBoolean);
        await this.http.post('/user/code.do', {
                phone: this.phonevalue,
            }
        ).subscribe(
            (success: ResponseData) => {
                if (success.code === '000000') {
                    this.countDownComp.startCount();
                    console.log('msg' + success.msg);
                } else {
                    alert(success.msg);
                    console.log('msg' + success.msg);
                }
            }, (error) => {
                this.codeBoolean=false;
                console.log(error);
            }
        );

    }
    endOfCount(data){
        this.codeBoolean=false;
    }

    async doChange() {
        await this.http.post('/user/changeBankCard.do', {
            cardNum: this.cardnumvalue,
            phone: this.phonevalue,
            code: this.validvalue
        }, {
            headers: {
                'Authorization': localStorage.getItem('sessionId')
            }
        }).subscribe(
            (success: ResponseData) => {
                if (success.code === '000000') {
                    console.log('msg' + success.msg);
                    alert(success.msg);
                    // 每次进入页面需要请求我的银行卡信息，这句需要注释掉
                    localStorage.setItem('cardNum', this.cardnumvalue);

                    this.nav.navigateForward('/card-added');
                } else {
                    alert(success.msg);
                    console.log('code:' + success.code);
                }
            }, (error) => {
                console.log(error);
            }
        );
    }

}
