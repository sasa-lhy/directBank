import {Component, OnInit} from '@angular/core';
import {DisplayUtilService} from '../../services/display-util/display-util.service';
import {NavController} from '@ionic/angular';
import {Constants} from '../../common/userStatus';
@Component({
    selector: 'app-setting',
    templateUrl: './setting.page.html',
    styleUrls: ['./setting.page.scss'],
})
export class SettingPage implements OnInit {
    server='';
    out() {
        localStorage.clear();
        this.display.showToast('注销成功');
        this.nav.navigateForward('/');
    }

    constructor(private display:DisplayUtilService,private nav:NavController) {
    }

    ngOnInit() {
    }
    setServer(){
        Constants.server_url=this.server;
        this.display.showToast('服务器临时修改成功！');
    }

    lookServe(){
        this.display.showOneAlert('服务器地址为:'+Constants.server_url);
    }
}
