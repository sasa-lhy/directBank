import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {HttpClient} from '@angular/common/http';
import {ResponseData} from '../../services/http/http-proceed-handler.service';
import {NavController} from '@ionic/angular';

@Component({
  selector: 'app-product',
  templateUrl: './product.page.html',
  styleUrls: ['./product.page.scss'],
})
export class ProductPage implements OnInit {
  pList;
  constructor(private router: Router,private http:HttpClient,private nav:NavController) {}

  ngOnInit() {
  }

    ionViewWillEnter(){
      this.getProductList();
    }

    // 获取理财产品列表
    async getProductList() {
        await this.http.post('/bank/myFund.do', {}).subscribe(
            (success: ResponseData) => {
                this.pList=success.data;
                console.log(success);
            }, (error) => {
                console.log(error);
            }
        );
    }

    async getProductInfo(productId) {
        this.http.post('/fund/query.do', {
            fundId: productId,
        }).subscribe(
            (success: ResponseData) => {
                if (success.code === '000000') {
                    this.enterProduct(success.data.name,success.data.money,success.data.rate,success.data.risk,productId,'true');
                }
            }, (error) => {
                console.log(error);
            }
        );

    }
    // 带参跳转置理财产品页
    enterProduct(name,money,rate,risk,fundId,opened) {
        this.router.navigate(['/money-product'], {
            skipLocationChange: true,
            queryParams: {
                name: name,
                money: money,
                rate:rate,
                risk:risk,
                open:opened,
                fundId:fundId
            }
        });
    }

    toMe(){
        this.nav.navigateBack('tabs/tab3');
    }

}
