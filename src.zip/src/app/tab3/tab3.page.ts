import {Component} from '@angular/core';
import {NavController} from '@ionic/angular';
import {DisplayUtilService} from '../services/display-util/display-util.service';
import {HttpClient} from '@angular/common/http';
import {Route} from '@angular/router';

@Component({
    selector: 'app-tab3',
    templateUrl: 'tab3.page.html',
    styleUrls: ['tab3.page.scss']
})
export class Tab3Page {
    logined: string;
    accountNum: string;

    constructor(private navTo: NavController,private display:DisplayUtilService,private http:HttpClient){
        if (localStorage.getItem('logined')) {
            this.logined = localStorage.getItem('logined');
        } else {
            this.logined = 'false';
        }
        if (localStorage.getItem('accountNumber')) {
            this.accountNum = '没有东西';
        } else {
            this.accountNum = localStorage.getItem('accountNumber');
        }
    }

    // 将进入页面时刷新
    ionViewWillEnter() {
        if (localStorage.getItem('logined')) {
            this.accountNum = localStorage.getItem('accountNumber');
            this.logined = localStorage.getItem('logined');
            console.log('ionViewWillEnter');
        }
    }

    // 跳转页面
    jumpTo(str: string) {
        if (localStorage.getItem('logined') && localStorage.getItem('logined') === 'true') {
            if (localStorage.getItem('opened') && localStorage.getItem('opened') === 'true') {
                this.navTo.navigateForward(str);
            } else {
                this.display.showAlert();
            }

        } else {
            this.display.showAlert('您尚未登陆，是否前往登陆？','去登陆','/login');
        }

    }

    //
    jump1To(str: string) {
        if (localStorage.getItem('logined') && localStorage.getItem('logined') === 'true') {

            this.navTo.navigateForward(str);

        } else {
            this.display.showAlert('您尚未登陆，是否前往登陆？','去登陆','/login');
        }
    }

    jump2To() {
        if (localStorage.getItem('logined') && localStorage.getItem('logined') === 'true') {
            if (localStorage.getItem('opened') && localStorage.getItem('opened') === 'true') {
                this.navTo.navigateForward('/card-added');
            } else {
                this.navTo.navigateForward('/card');
            }

        } else {
            this.display.showAlert('您尚未登陆，是否前往登陆？','去登陆','/login');
        }
    }

}
