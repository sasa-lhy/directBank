import {Component, OnInit, ViewChild} from '@angular/core';
import {CountDownComponent} from '../../components/count-down/count-down.component';
import {HttpClient} from '@angular/common/http';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {NavController} from '@ionic/angular';
import {ResponseData} from '../../services/http/http-proceed-handler.service';

@Component({
    selector: 'app-register',
    templateUrl: './register.page.html',
    styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
    phonevalue = '';
    validvalue = '';
    passwordvalue = '';
    registerForm: FormGroup;
    mobileControl: AbstractControl;
    passwordControl: AbstractControl;
    validcodeControl: AbstractControl;
    codeBoolean = false;
    @ViewChild(CountDownComponent) countDownComp: CountDownComponent;

    constructor(private http: HttpClient, private fb: FormBuilder, private nav: NavController) {
        this.registerForm = this.fb.group({
            mobile: ['', Validators.compose([Validators.required, Validators.pattern(/^[1][3,4,5,6,7,8][0-9]{9}$/)])],
            validcode: ['', Validators.compose([Validators.required, Validators.pattern(/^[0-9]{6}$/)])],
            password: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9]{6,16}$/)])],
        });
        this.mobileControl = this.registerForm.controls.mobile;
        this.passwordControl = this.registerForm.controls.password;
        this.validcodeControl = this.registerForm.controls.validcode;
    }

    async getCode() {
        this.codeBoolean=true;
        console.log(this.codeBoolean);
        await this.http.post('/user/code.do', {
                phone: this.phonevalue,
            }
        ).subscribe(
            (success: ResponseData) => {
                if (success.code === '000000') {
                    this.countDownComp.startCount();
                    console.log('msg' + success.msg);
                } else {
                    alert(success.msg);
                    console.log('msg' + success.msg);
                }
            }, (error) => {
                this.codeBoolean=false;
                console.log(error);
            }
        );

    }
    endOfCount(data){
        this.codeBoolean=false;
    }
    async doRegister() {
        await this.http.post('/user/register.do', {
            account: this.phonevalue,
            password: this.passwordvalue,
            code: this.validvalue
        }).subscribe(
            (success: ResponseData) => {
                console.log('code' + success.code);
                console.log('msg' + success.msg);
                if (success.code === '000000') {
                    this.nav.navigateForward('/login');
                } else {
                    alert(success.msg);
                }

            }, (error) => {
                console.log(error);
            }
        );
    }

    ngOnInit() {
    }
}


