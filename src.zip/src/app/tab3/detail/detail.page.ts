import {Component, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {ResponseData} from '../property/property.page';
import {NavController} from '@ionic/angular';

@Component({
    selector: 'app-detail',
    templateUrl: './detail.page.html',
    styleUrls: ['./detail.page.scss'],
})

export class DetailPage implements OnInit {
    type = '转入/出';
    money = '+0.00';
    time ='XXXX-XX-XX';
    result = '交易成功/失败';
    list=[{
        type:'转入',
        money:'+10',
        createTime:'2019-3-14',
        remark:'交易成功'
    },{
        type:'转入',
        money:'+10',
        createTime:'2019-3-14',
        remark:'交易成功'
    }
    ];
    constructor(private http:HttpClient,private nav:NavController) {
        //this.getList();
    }

    ngOnInit() {
    }
    ionViewWillEnter() {
        this.getList();
    }
    async getList(){
        await this.http.post('/bank/traderecord.do',{

        }).subscribe(
            (success:ResponseData )=>{
                if(success.code=='000000'){
                    console.log(success.data);
                    this.list=success.data.record;
                }
            },(error)=>{
                console.log(error);
            }
        )
    }

    toMe(){
        this.nav.navigateBack('tabs/tab3');
    }
}
