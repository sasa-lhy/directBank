import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { ManageLoginPassPage } from './manage-login-pass.page';

const routes: Routes = [
  {
    path: '',
    component: ManageLoginPassPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [ManageLoginPassPage]
})
export class ManageLoginPassPageModule {}
