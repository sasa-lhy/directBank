import { Component, OnInit } from '@angular/core';
import {NavController} from '@ionic/angular';

@Component({
  selector: 'app-manage-login-pass',
  templateUrl: './manage-login-pass.page.html',
  styleUrls: ['./manage-login-pass.page.scss'],
})
export class ManageLoginPassPage implements OnInit {

  constructor(private nav: NavController) { }

  ngOnInit() {
  }
    toMe(){
        this.nav.navigateRoot('/tabs/tab3');
    }

}
