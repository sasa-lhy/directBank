import {Component, OnInit} from '@angular/core';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {HttpClient} from '@angular/common/http';
import {NavController} from '@ionic/angular';
import {ResponseData} from '../../../services/http/http-proceed-handler.service';

@Component({
    selector: 'app-reset-pass',
    templateUrl: './reset-pass.page.html',
    styleUrls: ['./reset-pass.page.scss'],
})
export class ResetPassPage implements OnInit {
    oldvalue = '';
    newvalue = '';
    resetForm: FormGroup;
    oldPassControl: AbstractControl;
    newPassControl: AbstractControl;

    constructor(private fb: FormBuilder, private http: HttpClient, private nav: NavController) {
        this.resetForm = this.fb.group({
            oldPass: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9]{6,16}$/)])],
            newPass: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9]{6,16}$/)])]
        });
        this.oldPassControl = this.resetForm.controls.oldPass;
        this.newPassControl = this.resetForm.controls.newPass;
    }

    ngOnInit() {
    }

    async doReset() {
        console.log('开始设置交易密码！');
        await this.http.post('/user/reset.do', {
            oldPwd: this.oldvalue,
            newPwd: this.newvalue,
        }, {
            headers: {
                'Authorization': localStorage.getItem('sessionId')
            }
        }).subscribe(
            (success: ResponseData) => {
                if (success.code === '000000') {
                    localStorage.setItem('logined', 'false');
                    this.nav.navigateForward('/login');
                    alert(success.msg);
                }
                console.log('code' + success.code);
                console.log('msg' + success.msg);
            }, (error) => {
                console.log(error);
            }
        );
    }

}

