import {Component, OnInit, ViewChild} from '@angular/core';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {HttpClient} from '@angular/common/http';
import {NavController} from '@ionic/angular';
import {CountDownComponent} from '../../../components/count-down/count-down.component';
import {ResponseData} from '../../../services/http/http-proceed-handler.service';

@Component({
    selector: 'app-forget-pass',
    templateUrl: './forget-pass.page.html',
    styleUrls: ['./forget-pass.page.scss'],
})
export class ForgetPassPage implements OnInit {
    forgetForm: FormGroup;
    phonevalue = '';
    validvalue = '';
    passwordvalue = '';
    passwordvalue1 = '';
    mobileControl: AbstractControl;
    passwordControl1: AbstractControl;
    passwordControl2: AbstractControl;
    validcodeControl: AbstractControl;
    codeBoolean = false;
    @ViewChild(CountDownComponent) countDownComp: CountDownComponent;

    constructor(private fb: FormBuilder, private http: HttpClient, private nav: NavController) {
        this.forgetForm = this.fb.group({
            mobile: ['', Validators.compose([Validators.required, Validators.pattern(/^[1][3,4,5,6,7,8][0-9]{9}$/)])],
            validcode: ['', Validators.compose([Validators.required, Validators.pattern(/^[0-9]{6}$/)])],
            password1: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9]{6,16}$/)])],
            password2: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9]{6,16}$/)])],
        });
        this.mobileControl = this.forgetForm.controls.mobile;
        this.passwordControl1 = this.forgetForm.controls.password1;
        this.passwordControl2 = this.forgetForm.controls.password2;
        this.validcodeControl = this.forgetForm.controls.validcode;
    }

    async getCode() {
        this.codeBoolean=true;
        console.log(this.codeBoolean);
        await this.http.post('/user/code.do', {
            phone: this.phonevalue,
        }).subscribe(
            (success: ResponseData) => {
                if (success.code === '000000') {
                    this.countDownComp.startCount();
                    console.log('msg' + success.msg);
                } else {
                    alert(success.msg);
                    console.log('msg' + success.msg);
                }
            }, (error) => {
                this.codeBoolean=false;
                console.log(error);
            }
        );

    }

    endOfCount(data){
        this.codeBoolean=false;
    }

    async doForget() {
        await this.http.post('/user/updatePassword.do', {
            account: this.phonevalue,
            newPassword: this.passwordvalue,
            code: this.validvalue
        }).subscribe(
            (success: ResponseData) => {
                console.log('code' + success.code);
                console.log('msg' + success.msg);
                if (success.code === '000000') {
                    this.nav.navigateForward('/login');
                    localStorage.setItem('logined', 'false');
                } else {
                    alert(success.msg);
                }

            }, (error) => {
                console.log(error);
            }
        );
    }

    ngOnInit() {
    }

}


