import {Component, OnInit} from '@angular/core';
import {NavController} from '@ionic/angular';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {HttpClient} from '@angular/common/http';
import {ResponseData} from '../../services/http/http-proceed-handler.service';

@Component({
    selector: 'app-login',
    templateUrl: './login.page.html',
    styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
    phonevalue = '';
    passwordvalue = '';
    loginForm: FormGroup;
    mobileControl: AbstractControl;
    passwordControl: AbstractControl;

    constructor(private nav: NavController, private fb: FormBuilder, private http: HttpClient) {
        this.loginForm = this.fb.group({
            mobile: ['', Validators.compose([Validators.required, Validators.pattern(/^[1][3,4,5,7,8][0-9]{9}$/)])],
            password: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9]{6,16}$/)])]
        });
        this.mobileControl = this.loginForm.controls.mobile;
        this.passwordControl = this.loginForm.controls.password;
    }

    // 返回tab3
    back() {
        this.nav.navigateRoot('/tabs/tab3');
    }

    async login() {
        await this.http.post('/user/login.do', {
            account: this.phonevalue,
            password: this.passwordvalue,
        }).subscribe(
            (success: ResponseData) => {
                if (success.code === '000000') {
                    localStorage.setItem('logined', 'true');
                    localStorage.setItem('accountNumber', success.data.mobile);
                    localStorage.setItem('sessionId', success.data.sessionId);
                    if (success.data.eAccount) {
                        console.log(success.data.eAccount);
                        localStorage.setItem('opened', 'true');
                        console.log(localStorage.getItem('opened'));
                    }
                    this.nav.navigateForward('/tabs/tab3');

                }

            }, (error) => {
                console.log(error);
            }
        );
    }

    ngOnInit() {
    }

    registerNow() {
        this.nav.navigateForward('/register');
    }

    toMe(){
        this.nav.navigateRoot('/tabs/tab3');
    }

}
