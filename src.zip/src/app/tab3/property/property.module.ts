import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {Routes, RouterModule} from '@angular/router';

import {IonicModule} from '@ionic/angular';

import {PropertyPage} from './property.page';
import {DirectivesModule} from '../../directives/directives.module';

const routes: Routes = [
    {
        path: '',
        component: PropertyPage
    }
];

@NgModule({
    imports: [
        DirectivesModule,
        CommonModule,
        FormsModule,
        IonicModule,
        RouterModule.forChild(routes)
    ],
    declarations: [PropertyPage]
})
export class PropertyPageModule {

}
