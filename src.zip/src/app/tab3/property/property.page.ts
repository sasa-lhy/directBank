import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {NavController} from '@ionic/angular';

@Component({
  selector: 'app-property',
  templateUrl: './property.page.html',
  styleUrls: ['./property.page.scss'],
})
export class PropertyPage implements OnInit {
    moneyLeft;
    moneyFond;
    totalMoney;
    options;
    tu=false;
  constructor(private http:HttpClient,private nav:NavController) {
      //this.getInfo();
  }

  async getInfo(){
      await this.http.post('/bank/queryasset.do',{

      }).subscribe(
          (success:ResponseData )=>{
              if(success.code=='000000'){
                  console.log(success.data);
                  this.moneyLeft=success.data.money;
                  this.moneyFond=success.data.fundsmoney;
                  this.totalMoney=success.data.totalmoney;
                  this.options = {
                      series: {
                          radius: ['50%', '70%'],
                          type: 'pie',
                          avoidLabelOverlap: false,
                          label: {
                              normal: {
                                  show: false,
                                  position: 'center'
                              },
                              emphasis: {
                                  show: true,
                                  textStyle: {
                                      fontSize: '16',
                                      fontWeight: 'bold'
                                  }
                              }
                          },
                          labelLine: {
                              normal: {
                                  show: false
                              }
                          },
                          data: [
                              {name: '账户余额', value: this.moneyLeft},
                              {name: '基金持仓', value: this.moneyFond},
                          ]
                      },
                      toolTips: {}
                  };
                  this.tu=true;
              }
          },(error)=>{
              console.log(error);
          }
      )
  }

    toMe(){
        this.nav.navigateBack('tabs/tab3');
    }
    ionViewWillEnter() {
        this.getInfo();
    }
  ngOnInit() {
  }

}
export interface ResponseData {
    code: string;
    data: any;
    msg: string;
}

