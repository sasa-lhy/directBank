import {Component, OnInit, ViewChild} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {NavController} from '@ionic/angular';
import {CountDownComponent} from '../../../components/count-down/count-down.component';

@Component({
    selector: 'app-forget-paypwd',
    templateUrl: './forget-paypwd.page.html',
    styleUrls: ['./forget-paypwd.page.scss'],
})
export class ForgetPaypwdPage implements OnInit {
    @ViewChild(CountDownComponent) countDownComp: CountDownComponent;
    conformForm: FormGroup;
    cardNumber = '';
    realName = '';
    idCard = '';
    phoneNum = '';
    passwordvalue = '';
    passwordvalue1 = '';
    code = '';
    cardNumberControl: AbstractControl;
    realNameControl: AbstractControl;
    idCardControl: AbstractControl;
    phoneNumControl: AbstractControl;
    codeControl: AbstractControl;
    passwordControl1: AbstractControl;
    passwordControl2: AbstractControl;
    codeBoolean = false;
    constructor(private fb: FormBuilder, private http: HttpClient, private nav: NavController) {
        this.conformForm = this.fb.group({
            cardNumber: ['', Validators.compose([Validators.required, Validators.pattern(/^[0-9]{18}$/)])],
            realName: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z\u4e00-\u9fa5]+$/)])],
            idCard: ['', Validators.compose([Validators.required, Validators.pattern(/^[0-9]{17}[0-9X]$/)])],
            phoneNum: ['', Validators.compose([Validators.required, Validators.pattern(/^[1][3,4,5,6,7,8][0-9]{9}$/)])],
            code: ['', Validators.compose([Validators.required, Validators.pattern(/^[0-9]{6}$/)])],
            password1: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9]{6,16}$/)])],
            password2: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9]{6,16}$/)])],
        });
        this.cardNumberControl = this.conformForm.controls.cardNumber;
        this.realNameControl = this.conformForm.controls.realName;
        this.idCardControl = this.conformForm.controls.idCard;
        this.phoneNumControl = this.conformForm.controls.phoneNum;
        this.codeControl = this.conformForm.controls.code;
        this.passwordControl1 = this.conformForm.controls.password1;
        this.passwordControl2 = this.conformForm.controls.password2;
    }


    async getCode() {
        this.codeBoolean=true;
        console.log(this.codeBoolean);
        await this.http.post('/user/code.do', {
            phone: this.phoneNum
        }).subscribe(
            (success: ResponseData) => {
                if (success.code === '000000') {
                    this.countDownComp.startCount();
                    console.log('msg' + success.msg);
                } else {
                    alert(success.msg);
                    console.log('msg' + success.msg);
                }
            }, (error) => {
                this.codeBoolean=false;
                console.log(error);
            }
        );

    }
    endOfCount(data){
        this.codeBoolean=false;
    }
    async doConform() {
        await this.http.post('/user/forgetTradePassWd.do', {
            cardNum: this.cardNumber,
            trueName: this.realName,
            idNum: this.idCard,
            phone: this.phoneNum,
            code: this.code,
            passWd: this.passwordvalue,
        }, {
            headers: {
                'Authorization': localStorage.getItem('sessionId')
            }
        }).subscribe(
            (success: ResponseData) => {
                if (success.code === '000000') {
                    console.log('msg' + success.msg);
                    this.nav.navigateForward('/set-password');
                } else {
                    alert(success.msg);
                    console.log('msg' + success.msg);
                }
            }, (error) => {
                console.log(error);
            }
        );
    }

    ngOnInit() {
    }
}

export interface ResponseData{
    code: string;
    data: any;
    msg: string;
}
