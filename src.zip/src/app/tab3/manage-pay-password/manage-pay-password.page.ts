import { Component, OnInit } from '@angular/core';
import {NavController} from '@ionic/angular';

@Component({
  selector: 'app-manage-pay-password',
  templateUrl: './manage-pay-password.page.html',
  styleUrls: ['./manage-pay-password.page.scss'],
})
export class ManagePayPasswordPage implements OnInit {

  constructor(private nav: NavController, ) { }

  ngOnInit() {
  }
    toMe(){
        this.nav.navigateRoot('/tabs/tab3');
    }

}
