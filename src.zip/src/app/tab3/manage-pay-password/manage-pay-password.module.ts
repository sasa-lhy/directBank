import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { ManagePayPasswordPage } from './manage-pay-password.page';

const routes: Routes = [
  {
    path: '',
    component: ManagePayPasswordPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [ManagePayPasswordPage]
})
export class ManagePayPasswordPageModule {}
