import {NgModule} from '@angular/core';
import {PreloadAllModules, RouterModule, Routes} from '@angular/router';

const routes: Routes = [
    {path: '', loadChildren: './tabs/tabs.module#TabsPageModule'},
    {path: 'property', loadChildren: './tab3/property/property.module#PropertyPageModule'},
    {path: 'card', loadChildren: './tab3/card/card.module#CardPageModule'},
    {path: 'product', loadChildren: './tab3/product/product.module#ProductPageModule'},
    {path: 'setting', loadChildren: './tab3/setting/setting.module#SettingPageModule'},
    {path: 'login', loadChildren: './tab3/login/login.module#LoginPageModule'},
    {path: 'register', loadChildren: './tab3/register/register.module#RegisterPageModule'},
    {path: 'detail', loadChildren: './tab3/detail/detail.module#DetailPageModule'},
    {path: 'add-card', loadChildren: './tab3/card/add-card/add-card.module#AddCardPageModule'},
    {path: 'verify', loadChildren: './tab3/card/verify/verify.module#VerifyPageModule'},
    {path: 'set-password', loadChildren: './tab3/card/set-password/set-password.module#SetPasswordPageModule'},
    {path: 'roll-in', loadChildren: './tab2/roll-in/roll-in.module#RollInPageModule'},
    {path: 'roll-out', loadChildren: './tab2/roll-out/roll-out.module#RollOutPageModule'},
    {path: 'card-added', loadChildren: './tab3/card-added/card-added.module#CardAddedPageModule'},
    {path: 'forget-pass', loadChildren: './tab3/login/forget-pass/forget-pass.module#ForgetPassPageModule'},
    {path: 'manage-login-pass', loadChildren: './tab3/manage-login-pass/manage-login-pass.module#ManageLoginPassPageModule'},
    {path: 'reset-pass', loadChildren: './tab3/manage-login-pass/reset-pass/reset-pass.module#ResetPassPageModule'},
  { path: 'show-card', loadChildren: './tab3/card/show-card/show-card.module#ShowCardPageModule' },
  { path: 'manage-pay-password', loadChildren: './tab3/manage-pay-password/manage-pay-password.module#ManagePayPasswordPageModule' },
  { path: 'forget-paypwd', loadChildren: './tab3/manage-pay-password/forget-paypwd/forget-paypwd.module#ForgetPaypwdPageModule' },
  { path: 'reset-paypwd', loadChildren: './tab3/manage-pay-password/reset-paypwd/reset-paypwd.module#ResetPaypwdPageModule' },
  { path: 'change-card', loadChildren: './tab3/card-added/change-card/change-card.module#ChangeCardPageModule' },
  { path: 'money-product', loadChildren: './tab1/money-product/money-product.module#MoneyProductPageModule' },
  { path: 'buy-product', loadChildren: './tab1/buy-product/buy-product.module#BuyProductPageModule' },
  { path: 'get-money', loadChildren: './tab1/get-money/get-money.module#GetMoneyPageModule' },
];

@NgModule({
    imports: [
        RouterModule.forRoot(routes, {preloadingStrategy: PreloadAllModules})
    ],
    exports: [RouterModule]
})
export class AppRoutingModule {
}
