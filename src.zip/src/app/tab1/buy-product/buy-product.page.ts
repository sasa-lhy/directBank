import {Component, OnInit} from '@angular/core';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {NavController} from '@ionic/angular';
import {HttpClient} from '@angular/common/http';
import {DisplayUtilService} from '../../services/display-util/display-util.service';
import {ActivatedRoute, Params} from '@angular/router';
@Component({
    selector: 'app-buy-product',
    templateUrl: './buy-product.page.html',
    styleUrls: ['./buy-product.page.scss'],
})
export class BuyProductPage implements OnInit {
    name = '天天赚';
    bankType = '农业银行';
    cardNum = '1234';
    ifenter = false;
    buyForm: FormGroup;
    money = '';
    payWay = 'bank';
    password='';
    moneyControl: AbstractControl;
    payWayControl: AbstractControl;
    fundId;

    constructor(private fb: FormBuilder, private http: HttpClient, private nav: NavController,private display:DisplayUtilService,private activeRoute:ActivatedRoute) {
        this.buyForm = this.fb.group({
            money: ['', Validators.compose([Validators.required, Validators.pattern(/^[0-9.]+$/)])],
            payWay: ['', Validators.compose([Validators.required])]
        });
        this.moneyControl = this.buyForm.controls.money;
        this.payWayControl = this.buyForm.controls.payWay;
    }

    ngOnInit() {
    }
    enterPass() {
        this.ifenter = true;
    }
    cancel(event) {
        console.log(event);
        event.stopPropagation();
        this.ifenter = false;
        this.password='';
    }
    stopP(event){
        event.stopPropagation();
        return false;
    }

    async doBuy(event){
        if (event.target.value.length === 6) {
            this.password = event.target.value;
            await this.http.post('/fund/buyFund.do', {
                money:parseFloat(this.money).toFixed(2),
                password: this.password,
                payWay: this.payWay,
                fundId:this.fundId
            }).subscribe(
                () => {
                    this.ifenter = false;
                    this.password='';
                    this.money='';
                },()=>{
                    this.ifenter = false;
                    this.password='';
                }
            );
        }
    }
    ionViewWillEnter(){
        this.activeRoute.queryParams.subscribe((params: Params) => {
            this.fundId=params['fundId'];
        });
    }
    tipAgree(){
        this.display.showOneAlert('如想购买该理财产品，需同意此协议！')
    }
}
