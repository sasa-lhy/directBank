import {Component, OnInit} from '@angular/core';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {HttpClient} from '@angular/common/http';
import {NavController} from '@ionic/angular';
import {ActivatedRoute, Params} from '@angular/router';

@Component({
    selector: 'app-get-money',
    templateUrl: './get-money.page.html',
    styleUrls: ['./get-money.page.scss'],
})
export class GetMoneyPage implements OnInit {
    name: '';
    account = '(1234)';
    totalMoney = '***';
    ifenter = false;
    fundId;
    getForm: FormGroup;
    money = '';
    password = '';
    agree;
    moneyControl: AbstractControl;
    agreeControl: AbstractControl;

    constructor(private fb: FormBuilder, private http: HttpClient, private nav: NavController, private activeRoute: ActivatedRoute) {
        this.getForm = this.fb.group({
            money: ['', Validators.compose([Validators.required, Validators.pattern(/^[0-9.]+$/)])],
            agree: [''],
        });
        this.moneyControl = this.getForm.controls.money;
        this.agreeControl = this.getForm.controls.agree;
    }

    enterPass() {
        this.ifenter = true;
    }

    ngOnInit() {
    }

    cancel(event) {
        console.log(event);
        event.stopPropagation();
        this.ifenter = false;
        this.password='';
    }

    stopP(event) {
        event.stopPropagation();
        return false;
    }

    async doGet(event) {
        if (event.target.value.length === 6) {
            this.password = event.target.value;
            await this.http.post('/fund/sellFund.do', {
                money: parseFloat(this.money).toFixed(2),
                password: this.password,
                fundId:this.fundId
            }).subscribe(
                () => {
                    this.ifenter = false;
                    this.password='';
                    this.money='';
                },()=>{
                this.ifenter = false;
                this.password='';
            }
            );
        }
    }

    ionViewWillEnter() {
        this.activeRoute.queryParams.subscribe((params: Params) => {
            this.fundId = params['fundId'];
            this.totalMoney = params['leftMoney'];
        });
    }

    doGetAll(){
        this.money=this.totalMoney;
        this.enterPass()
    }
}
