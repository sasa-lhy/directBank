import {Component, OnInit} from '@angular/core';
import {DisplayUtilService} from '../../services/display-util/display-util.service';
import {ActivatedRoute, Params, Router} from '@angular/router';

@Component({
    selector: 'app-money-product',
    templateUrl: './money-product.page.html',
    styleUrls: ['./money-product.page.scss'],
})
export class MoneyProductPage implements OnInit {
    name = '***';
    rate = '%';
    money = '0.00';
    risk = '*';
    unopened1 = true;
    unopened2 = true;
    fundId;

    constructor(private display: DisplayUtilService, private activeRoute: ActivatedRoute, private router: Router) {
    }

    ionViewWillEnter() {
        this.activeRoute.queryParams.subscribe((params: Params) => {
            this.name = params['name'];
            this.money = params['money'];
            this.rate = params['rate'];
            this.risk = params['risk'];
            this.fundId = params['fundId'];
            console.log(params['open']);
            if (params['open'] === 'true') {
                console.log('hh');
                this.unopened1 = false;
                this.unopened2 = false;
            } else {
                console.log('hh');
                this.unopened1 = true;
                this.unopened2 = true;
            }
            console.log(this.unopened1);
            console.log(this.unopened2);
        });
        if (this.money === '0.00') {
            this.unopened2 = true;
        }

    }

    toNext(url) {
        this.router.navigate([url], {
            skipLocationChange: true,
            queryParams: {
                leftMoney: this.money,
                fundId: this.fundId
            }
        });
    }

    ngOnInit() {
    }

}
