import {Component} from '@angular/core';
import {Router} from '@angular/router';
import {HttpClient} from '@angular/common/http';
import {ResponseData} from '../services/http/http-proceed-handler.service';

@Component({
    selector: 'app-tab1',
    templateUrl: 'tab1.page.html',
    styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
    pList;
    options: any = {
        autoplay: true,
        loop: true,
        effect:'cube',
    };

    constructor(private router: Router, private http: HttpClient) {

    }
    ionViewWillEnter() {
        this.getProductList();
    }

    // 带参跳转置理财产品页
    enterProduct(name,money,rate,risk,fundId,opened) {
        this.router.navigate(['/money-product'], {
            skipLocationChange: true,
            queryParams: {
                name: name,
                money: money,
                rate:rate,
                risk:risk,
                open:opened,
                fundId:fundId
            }
        });
    }

    // 获取理财产品的详细信息
    async getProductInfo1(productId) {
        this.http.post('/fund/query.do', {
            fundId: productId,
        }).subscribe(
            (success: ResponseData) => {
                if (success.code === '000000') {
                    this.enterProduct(success.data.name,success.data.money,success.data.rate,success.data.risk,productId,'true');
                }
            }, (error) => {
                console.log(error);
            }
        );

    }

    async getProductInfo2(productId) {
        this.http.post('/app/fundInfo.do', {
            fundId: productId,
        }).subscribe(
            (success: ResponseData) => {
                if (success.code === '000000') {
                    this.enterProduct(success.data.name,success.data.money,success.data.rate,success.data.risk,productId,'false');
                }
            }, (error) => {
                console.log(error);
            }
        );

    }

    async getProductInfo(productId) {
        if(localStorage.getItem('opened')&&localStorage.getItem('opened')==='true'){
            this.getProductInfo1(productId);
        }else{
            this.getProductInfo2(productId);
        }
    }

    // 获取理财产品列表
    async getProductList() {
        await this.http.post('/app/findFunds.do', {}).subscribe(
            (success: ResponseData) => {
                this.pList=success.data;
                console.log(success);
            }, (error) => {
                console.log(error);
            }
        );
    }

    //获取首页轮播图列表
    async getPic() {
        await this.http.post('', {}).subscribe(
            (success:ResponseData) => {
                this.pList=success.data;
            }, (error) => {

            }
        );
    }
}
