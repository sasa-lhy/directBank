import { NgModule } from '@angular/core';
import { AddPieDirective } from './add-pie.directive';
import { ImgDefaultDirective } from './img-default.directive';
@NgModule({
    declarations: [AddPieDirective, ImgDefaultDirective],
    imports: [],
    exports: [AddPieDirective,ImgDefaultDirective]
})
export class DirectivesModule {}
