import {Directive, ElementRef, Input} from '@angular/core';
import * as echarts from 'echarts';

@Directive({
    selector: '[appAddPie]'
})
export class AddPieDirective {
    private el: ElementRef;
    private _options: object;
    @Input('appAddPie')
    set options(value: object) {
        this._options = value;
        console.log(this._options);
        this.createPie();
    }

    constructor(el: ElementRef) {
        this.el = el;
    }

    createPie() {
        // this.viewContainer.createEmbeddedView(this.templateRef);
        // console.log(this.templateRef);
        console.log(this.el.nativeElement);
        this.el.nativeElement.innerHTML = 'blue';
        echarts.init(this.el.nativeElement).setOption(this._options);

    }


}
