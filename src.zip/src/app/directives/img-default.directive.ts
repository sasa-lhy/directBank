import {Directive, ElementRef, HostListener, Input} from '@angular/core';

@Directive({
    selector: '[appImgDefault]'
})
export class ImgDefaultDirective {
    el: ElementRef;
    private _errorsrc: string;
    @Input('appImgDefault')
    set errorsrc(value: string) {
        this._errorsrc = value;
        console.log(this._errorsrc);
    }

    @HostListener('error')
    onError() {
        if (!this._errorsrc) {
            this.el.nativeElement.src = 'assets/image/shapes.svg';
        } else {
            this.el.nativeElement.src = this._errorsrc;
        }

    }

    constructor(el: ElementRef) {
        this.el = el;
    }

}
