import {Component} from '@angular/core';
import {NavController} from '@ionic/angular';
import {HttpClient} from '@angular/common/http';
import {ResponseData} from '../services/http/http-proceed-handler.service';

@Component({
    selector: 'app-tab2',
    templateUrl: 'tab2.page.html',
    styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
    account = '******************';
    myMoney = '****';
    myleftMoney = '****';
    btnOut = false;
    btnIn = false;

    constructor(private navCtrl: NavController, private http: HttpClient) {

    }

    toIn() {
        this.navCtrl.navigateForward('/roll-in');
    }

    toOut() {
        this.navCtrl.navigateForward('/roll-out');
    }

    ionViewWillEnter() {
        if (localStorage.getItem('opened') && localStorage.getItem('opened') === 'true') {
            this.btnIn=true;
            this.btnOut=true;
            this.getMsg();
        }
    }

    async getMsg() {
        await this.http.post('/bank/queryasset.do', {}).subscribe(
            (success: ResponseData) => {
                if (success.code === '000000') {
                    this.account = success.data.eaccount;
                    this.myMoney = success.data.totalmoney;
                    this.myleftMoney = success.data.money;
                }
            }, (error) => {
                console.log(error);
            }
        );
    }
}
