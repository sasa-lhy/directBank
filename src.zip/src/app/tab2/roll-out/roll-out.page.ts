import { Component, OnInit } from '@angular/core';
import {NavController} from '@ionic/angular';
import {HttpClient} from '@angular/common/http';
import {ResponseData} from '../../services/http/http-proceed-handler.service';

@Component({
  selector: 'app-roll-out',
  templateUrl: './roll-out.page.html',
  styleUrls: ['./roll-out.page.scss'],
})
export class RollOutPage implements OnInit {
    bankType='农业银行';
    cardNum='1234';
    ifenter = false;
    outMoney;
    password='';
    totalMoney;
    constructor( private http: HttpClient, private nav: NavController) {
        //this.getMsg();
    }
    enterPass() {
        this.ifenter = true;
    }

    ngOnInit() {
    }

    cancel(event) {
        console.log(event);
        event.stopPropagation();
        this.ifenter = false;
        this.password = '';
    }
    stopP(event){
        event.stopPropagation();
        return false;
    }

    ionViewWillEnter() {
        this.getMsg();
    }

    async doOut(event) {

        if (event.target.value.length === 6) {
            this.password = event.target.value;
            await this.http.post('/bank/withdrawal.do', {
                eaccountvalue: parseFloat(this.outMoney+"").toFixed(2),
                password: this.password,
            }).subscribe(
                (success:ResponseData) => {
                    this.totalMoney=success.data.totalmomey;
                    this.ifenter = false;
                    this.password = '';
                    this.outMoney='';
                },(error) =>{
                    console.log(error);
                    this.ifenter = false;
                    this.password = '';
                }
            );
        }
    }

    async getMsg() {
        await this.http.post('/bank/queryasset.do', {}).subscribe(
            (success:ResponseData) => {
                if(success.code==='000000'){
                    this.totalMoney= success.data.money;
                }
            }, (error) => {
                console.log(error);
            }
        );
    }
}
