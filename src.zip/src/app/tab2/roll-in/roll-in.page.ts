import {Component, OnInit} from '@angular/core';
import {NavController} from '@ionic/angular';
import {HttpClient} from '@angular/common/http';

@Component({
    selector: 'app-roll-in',
    templateUrl: './roll-in.page.html',
    styleUrls: ['./roll-in.page.scss'],
})
export class RollInPage implements OnInit {
    bankType = 'XX银行';
    cardNum = '1234';
    ifenter = false;

    inMoney:number;
    password = '';


    constructor(private http: HttpClient, private nav: NavController) {
    }

    enterPass() {
        this.ifenter = true;
    }

    ngOnInit() {
    }

    cancel(event) {
        console.log(event);
        event.stopPropagation();
        this.ifenter = false;
        this.password = '';
    }

    stopP(event) {
        event.stopPropagation();
        return false;
    }

    async doIn(event) {

        if (event.target.value.length === 6) {
            this.password = event.target.value;
            await this.http.post('/bank/recharge.do', {
                eaccountvalue:parseFloat(this.inMoney+"").toFixed(2),
                password: this.password,
            }).subscribe(
                () => {
                    this.ifenter = false;
                    this.password = '';
                },()=>{
                    this.ifenter = false;
                    this.password='';
                }
            );
        }
    }


}
